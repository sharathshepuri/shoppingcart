package com.sharath.shoppingcart.service;

import com.sharath.shoppingcart.entity.ProductEntity;
import com.sharath.shoppingcart.repository.ProductRepository;
import com.sharath.shoppingcart.service.impl.ProductServiceImpl;
import org.junit.jupiter.api.Test;

import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.*;

public class ProductServiceTest {
    @Test
    public void testSaveProduct(){
        ProductRepository repository = mock(ProductRepository.class);
        ProductService productService = new ProductServiceImpl(repository);
        when(repository.save(anyObject())).thenReturn(getProductEntity());
        productService.saveProduct(getProductEntity());
        verify(repository,times(1)).save(any());
    }

    private static ProductEntity getProductEntity() {
        ProductEntity entity = new ProductEntity();
        entity.setProductId(100L);
        entity.setProductName("Dyson");
        entity.setProductPrice("499");
        return entity;
    }
}
