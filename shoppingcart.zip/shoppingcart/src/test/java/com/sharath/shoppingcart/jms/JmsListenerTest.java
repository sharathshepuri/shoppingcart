package com.sharath.shoppingcart.jms;


import com.sharath.shoppingcart.entity.ProductEntity;
import com.sharath.shoppingcart.service.ProductService;
import org.junit.jupiter.api.Test;
import org.springframework.jms.core.JmsTemplate;

import static org.mockito.Mockito.*;

public class JmsListenerTest {

    @Test
    public void testReceiveMessage(){
        ProductService productService = mock(ProductService.class);
        JmsTemplate jmsTemplate = mock(JmsTemplate.class);
        ProductEntity entity = getProductEntity();
        when(productService.saveProduct(entity)).thenReturn(getProductEntity());
        ShoppingCart shoppingCart = new ShoppingCart(productService,jmsTemplate);
        shoppingCart.receiveMessage(getProductEntity());
        verify(productService,times(1)).saveProduct(any());

    }

    private static ProductEntity getProductEntity() {
        ProductEntity entity = new ProductEntity();
        entity.setProductId(100L);
        entity.setProductName("Dyson");
        entity.setProductPrice("499");
        return entity;
    }
}
