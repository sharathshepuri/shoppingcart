package com.sharath.shoppingcart.jms;

import com.sharath.shoppingcart.entity.ProductEntity;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ReturnedObjListener {

    @JmsListener(destination = "returnedObject" ,containerFactory = "myFactory")
    public void receiveMessage(ProductEntity productEntity){
        System.out.println("Final product saved is "+productEntity);
    }
}
