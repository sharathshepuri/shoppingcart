package com.sharath.shoppingcart;

import com.sharath.shoppingcart.entity.ProductEntity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.core.JmsTemplate;

@SpringBootApplication
public class ShoppingcartApplication {

	public static void main(String[] args) {

		ConfigurableApplicationContext applicationContext = SpringApplication.run(ShoppingcartApplication.class, args);
		JmsTemplate jmsTemplate = applicationContext.getBean(JmsTemplate.class);
		jmsTemplate.convertAndSend("addToCart",getProductEntity());
	}

	private static ProductEntity getProductEntity() {
		ProductEntity entity = new ProductEntity();
		entity.setProductId(100L);
		entity.setProductName("Dyson");
		entity.setProductPrice("499");
		return entity;
	}

}
