package com.sharath.shoppingcart.service.impl;

import com.sharath.shoppingcart.entity.ProductEntity;
import com.sharath.shoppingcart.repository.ProductRepository;
import com.sharath.shoppingcart.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository repository) {
        this.productRepository = repository;
    }

    @Override
    public ProductEntity saveProduct(ProductEntity product) {/*
        ProductEntity productEntity = new ProductEntity();
        productEntity.setProductId(Long.parseLong(product.getProductId()));
        productEntity.setProductName(product.getProductName());
        productEntity.setProductPrice(product.getProductPrice().toString());*/
        return productRepository.save(product);
    }
}
