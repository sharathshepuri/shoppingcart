package com.sharath.shoppingcart.jms;

import com.sharath.shoppingcart.entity.ProductEntity;
import com.sharath.shoppingcart.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class ShoppingCart {
    @Autowired
    ProductService productService;

    @Autowired
    JmsTemplate jmsTemplate;

    public ShoppingCart(ProductService productService, JmsTemplate jmsTemplate) {
        this.productService = productService;
        this.jmsTemplate = jmsTemplate;
    }

    @JmsListener(destination = "addToCart" ,containerFactory = "myFactory")
    public void receiveMessage(ProductEntity productEntity){
        System.out.println("Product added to cart is "+productEntity);
        //Save this product in h2 db
        ProductEntity pe = productService.saveProduct(productEntity);
        System.out.println(pe);
        jmsTemplate.convertAndSend("returnedObject",pe);
    }
}
