package com.sharath.shoppingcart.service;

import com.sharath.shoppingcart.entity.ProductEntity;


public interface ProductService {
    ProductEntity saveProduct(ProductEntity product);
}
